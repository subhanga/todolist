package com.example.todoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.todoapp.db.TaskContract;
import com.example.todoapp.db.TaskDbHelper;

public class AddEditActivity extends AppCompatActivity {

    private TaskDbHelper mHelper;

    private boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        mHelper = new TaskDbHelper(this);
        final EditText cityname = (EditText) findViewById(R.id.editText);
        final EditText zipcode = (EditText) findViewById(R.id.editText2);
        Button add = (Button) findViewById(R.id.button);

        Intent i = getIntent();
        String gotcityname = i.getStringExtra("cityname");
        if(isNumeric(gotcityname)){
            zipcode.setText(gotcityname);
        }else{
            cityname.setText(gotcityname);
        }

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String city = cityname.getText().toString();
                String zipCode = zipcode.getText().toString();
                if(city.isEmpty()){
                    city = zipCode;
                }

                if(city.isEmpty()){
                    Toast.makeText(AddEditActivity.this, "Enter city  name or zip code", Toast.LENGTH_LONG).show();
                    return;
                }

                SQLiteDatabase db = mHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(TaskContract.TaskEntry.COL_TASK_TITLE, city);
                db.insertWithOnConflict(TaskContract.TaskEntry.TABLE,
                        null,
                        values,
                        SQLiteDatabase.CONFLICT_REPLACE);
                db.close();
                finish();
            }
        });
    }
}
